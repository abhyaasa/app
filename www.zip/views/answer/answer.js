angular.module('app')

.controller('AnswerController', function ($scope) {});
