'use strict';

angular.module('app')

.controller('AboutController', function () {
})
;
